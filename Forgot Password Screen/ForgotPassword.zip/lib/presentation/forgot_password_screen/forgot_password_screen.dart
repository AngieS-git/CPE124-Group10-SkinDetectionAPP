import 'package:flutter/material.dart';
import 'package:newredesgin/core/app_export.dart';
import 'package:newredesgin/widgets/custom_elevated_button.dart';
import 'package:newredesgin/widgets/custom_text_form_field.dart';

class ForgotPasswordScreen extends StatelessWidget {
  ForgotPasswordScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController passwordController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController newPasswordController = TextEditingController();

  TextEditingController newPasswordController1 = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 45.v,
                      width: 357.h,
                      margin: EdgeInsets.only(left: 1.h),
                      decoration: BoxDecoration(
                        color: appTheme.blueGray100,
                      ),
                    ),
                    SizedBox(height: 83.v),
                    Container(
                      width: 204.h,
                      margin: EdgeInsets.only(left: 49.h),
                      child: Text(
                        "FORGOT PASSWORD?",
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: CustomTextStyles.headlineLargeOnPrimary,
                      ),
                    ),
                    SizedBox(height: 21.v),
                    _buildPassword(context),
                    SizedBox(height: 9.v),
                    _buildEmail(context),
                    SizedBox(height: 9.v),
                    _buildNewPassword(context),
                    SizedBox(height: 9.v),
                    _buildNewPassword1(context),
                    SizedBox(height: 33.v),
                    _buildResetAccount(context),
                    Spacer(),
                    SizedBox(height: 3.v),
                    Container(
                      height: 45.v,
                      width: 357.h,
                      margin: EdgeInsets.only(left: 1.h),
                      decoration: BoxDecoration(
                        color: appTheme.blueGray100,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: passwordController,
        hintText: "Username",
      ),
    );
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: emailController,
        hintText: "E-mail",
        textInputType: TextInputType.emailAddress,
      ),
    );
  }

  /// Section Widget
  Widget _buildNewPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: newPasswordController,
        hintText: "New Password",
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildNewPassword1(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: newPasswordController1,
        hintText: "Confirm New Password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildResetAccount(BuildContext context) {
    return CustomElevatedButton(
      width: 244.h,
      text: "RESET ACCOUNT",
      margin: EdgeInsets.only(left: 49.h),
      buttonTextStyle: theme.textTheme.headlineSmall!,
    );
  }
}
