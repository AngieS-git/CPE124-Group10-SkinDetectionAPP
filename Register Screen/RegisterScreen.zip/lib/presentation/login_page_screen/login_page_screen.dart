import 'package:flutter/material.dart';
import 'package:newredesgin/core/app_export.dart';
import 'package:newredesgin/widgets/custom_elevated_button.dart';
import 'package:newredesgin/widgets/custom_text_form_field.dart';

class LoginPageScreen extends StatelessWidget {
  LoginPageScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: SizedBox(
          width: SizeUtils.width,
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgRectangle10,
                      height: 45.v,
                      width: 357.h,
                    ),
                    SizedBox(height: 51.v),
                    Container(
                      height: 153.adaptSize,
                      width: 153.adaptSize,
                      padding: EdgeInsets.symmetric(
                        horizontal: 32.h,
                        vertical: 31.v,
                      ),
                      decoration: AppDecoration.fillSecondaryContainer.copyWith(
                        borderRadius: BorderRadiusStyle.roundedBorder76,
                      ),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgLock,
                        height: 90.v,
                        width: 88.h,
                        alignment: Alignment.center,
                      ),
                    ),
                    SizedBox(height: 23.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgSettings,
                      height: 23.v,
                      width: 95.h,
                    ),
                    SizedBox(height: 39.v),
                    CustomTextFormField(
                      width: 244.h,
                      controller: userNameController,
                      hintText: "Username",
                    ),
                    SizedBox(height: 18.v),
                    CustomTextFormField(
                      width: 244.h,
                      controller: passwordController,
                      hintText: "Password",
                      textInputAction: TextInputAction.done,
                      textInputType: TextInputType.visiblePassword,
                      obscureText: true,
                    ),
                    SizedBox(height: 18.v),
                    CustomElevatedButton(
                      width: 244.h,
                      text: "LOGIN",
                    ),
                    SizedBox(height: 9.v),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: EdgeInsets.only(right: 57.h),
                        child: Text(
                          "forgot password",
                          style: theme.textTheme.labelMedium!.copyWith(
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 23.v),
                    CustomImageView(
                      imagePath: ImageConstant.imgDonTHaveAnAccount,
                      height: 11.v,
                      width: 207.h,
                    ),
                    SizedBox(height: 51.v),
                    Container(
                      height: 45.v,
                      width: 357.h,
                      decoration: BoxDecoration(
                        color: appTheme.blueGray100,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
