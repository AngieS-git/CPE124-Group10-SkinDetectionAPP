import 'package:flutter/material.dart';
import 'package:newredesgin/core/app_export.dart';
import 'package:newredesgin/widgets/custom_elevated_button.dart';
import 'package:newredesgin/widgets/custom_text_form_field.dart';

class RegisterPageScreen extends StatelessWidget {
  RegisterPageScreen({Key? key})
      : super(
          key: key,
        );

  TextEditingController fullNameController = TextEditingController();

  TextEditingController emailController = TextEditingController();

  TextEditingController mobileNumberController = TextEditingController();

  TextEditingController userNameController = TextEditingController();

  TextEditingController passwordController = TextEditingController();

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.only(
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: Form(
              key: _formKey,
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 45.v,
                      width: 357.h,
                      margin: EdgeInsets.only(left: 1.h),
                      decoration: BoxDecoration(
                        color: appTheme.blueGray100,
                      ),
                    ),
                    SizedBox(height: 35.v),
                    Container(
                      height: 140.adaptSize,
                      width: 140.adaptSize,
                      margin: EdgeInsets.only(left: 101.h),
                      padding: EdgeInsets.all(45.h),
                      decoration: AppDecoration.fillSecondaryContainer.copyWith(
                        borderRadius: BorderRadiusStyle.circleBorder70,
                      ),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgPlus,
                        height: 50.adaptSize,
                        width: 50.adaptSize,
                        alignment: Alignment.center,
                      ),
                    ),
                    SizedBox(height: 20.v),
                    _buildFullName(context),
                    SizedBox(height: 9.v),
                    _buildEmail(context),
                    SizedBox(height: 9.v),
                    _buildMobileNumber(context),
                    SizedBox(height: 9.v),
                    _buildUserName(context),
                    SizedBox(height: 9.v),
                    _buildPassword(context),
                    SizedBox(height: 20.v),
                    _buildRegisterButton(context),
                    SizedBox(height: 92.v),
                    Container(
                      height: 45.v,
                      width: 357.h,
                      margin: EdgeInsets.only(left: 1.h),
                      decoration: BoxDecoration(
                        color: appTheme.blueGray100,
                      ),
                    ),
                    SizedBox(height: 3.v),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildFullName(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: fullNameController,
        hintText: "Full Name",
      ),
    );
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: emailController,
        hintText: "E-mail",
        textInputType: TextInputType.emailAddress,
      ),
    );
  }

  /// Section Widget
  Widget _buildMobileNumber(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: mobileNumberController,
        hintText: "Mobile Number",
        textInputType: TextInputType.phone,
      ),
    );
  }

  /// Section Widget
  Widget _buildUserName(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: userNameController,
        hintText: "Username",
      ),
    );
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 49.h),
      child: CustomTextFormField(
        width: 244.h,
        controller: passwordController,
        hintText: "Password",
        textInputAction: TextInputAction.done,
        textInputType: TextInputType.visiblePassword,
        obscureText: true,
      ),
    );
  }

  /// Section Widget
  Widget _buildRegisterButton(BuildContext context) {
    return CustomElevatedButton(
      width: 244.h,
      text: "REGISTER",
      margin: EdgeInsets.only(left: 49.h),
    );
  }
}
