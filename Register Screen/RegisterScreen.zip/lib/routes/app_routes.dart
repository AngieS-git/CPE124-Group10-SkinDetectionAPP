import 'package:flutter/material.dart';
import 'package:newredesgin/presentation/login_page_screen/login_page_screen.dart';
import 'package:newredesgin/presentation/forgot_password_screen/forgot_password_screen.dart';
import 'package:newredesgin/presentation/register_page_screen/register_page_screen.dart';
import 'package:newredesgin/presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String loginPageScreen = '/login_page_screen';

  static const String forgotPasswordScreen = '/forgot_password_screen';

  static const String registerPageScreen = '/register_page_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static Map<String, WidgetBuilder> routes = {
    loginPageScreen: (context) => LoginPageScreen(),
    forgotPasswordScreen: (context) => ForgotPasswordScreen(),
    registerPageScreen: (context) => RegisterPageScreen(),
    appNavigationScreen: (context) => AppNavigationScreen()
  };
}
