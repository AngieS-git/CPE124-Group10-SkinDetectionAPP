class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Login Page images
  static String imgRectangle10 = '$imagePath/img_rectangle_10.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgSettings = '$imagePath/img_settings.svg';

  static String imgDonTHaveAnAccount =
      '$imagePath/img_don_t_have_an_account.svg';

  // Register Page images
  static String imgPlus = '$imagePath/img_plus.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
